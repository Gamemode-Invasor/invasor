A tiny archive Demo ships to show ctx.archive.
